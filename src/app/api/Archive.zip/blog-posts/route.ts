import { NextResponse } from 'next/server';

export async function GET() {
  const blogPosts = [
    {
      id: 1,
      title: 'Kính lọc CPL trong nhiếp ảnh: 4 công dụng và cách sử dụng',
      date: '15/07/2023',
      image: '/blog-1.jpg',
      excerpt: 'Kính lọc CPL trong nhiếp ảnh là một công cụ không thể thiếu, đặc biệt đối với những nhiếp ảnh gia chuyên chụp phong cảnh và ngoài trời....'
    },
    {
      id: 2,
      title: 'Đèn LED quay phim – chụp hình Ulanzi VL49 RGB',
      date: '09/06/2023',
      image: '/blog-2.jpg',
      excerpt: 'Video đánh giá chi tiết Đèn LED quay phim - chụp hình Ulanzi VL49 Đánh giá chung Đèn LED hỗ trợ quay phim - chụp hình...'
    },
    {
      id: 3,
      title: 'Gậy tự sướng tích hợp tripod Benro MK10P',
      date: '20/05/2023',
      image: '/blog-3.jpg',
      excerpt: 'Gậy tự sướng tích hợp tripod Benro MK10P phiên bản 2019. Phiên bản mới với nhiều cải tiến thiết kế đẹp và sang trọng hơn...'
    },
    {
      id: 4,
      title: 'So sánh khác nhau giữa softbox tự giác và softbox bật giác',
      date: '03/04/2023',
      image: '/blog-4.jpg',
      excerpt: 'Tổng quan đánh giá 2 softbox tự giác và softbox bật giác: Softbox là một trong những công cụ quan trọng trong nhiếp ảnh chuyên nghiệp...'
    }
  ];
  
  return NextResponse.json({ blogPosts });
} 