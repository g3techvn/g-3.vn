import { NextResponse } from 'next/server';

export async function GET() {
  const carouselItems = [
    {
      id: 1,
      title: 'Phụ kiện',
      subtitle: 'INSTA360 X4',
      image: '/insta360-x4-banner.jpg',
      buttonText: 'Xem ngay',
      buttonLink: '/product-category/insta360',
      backgroundColor: 'bg-black'
    },
    {
      id: 2,
      title: 'GOPRO 13',
      subtitle: 'Phụ kiện chất lượng',
      image: '/gopro-banner.jpg',
      buttonText: 'Khám phá ngay',
      buttonLink: '/product-category/gopro',
      backgroundColor: 'bg-red-600'
    },
    {
      id: 3,
      title: 'Phụ kiện Apple',
      subtitle: 'Dành cho iPhone 15',
      image: '/iphone-banner.jpg',
      buttonText: 'Mua ngay',
      buttonLink: '/product-category/apple',
      backgroundColor: 'bg-red-600'
    }
  ];
  
  return NextResponse.json({ carouselItems });
} 