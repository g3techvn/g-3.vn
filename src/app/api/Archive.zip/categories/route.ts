import { NextResponse } from 'next/server';

export async function GET() {
  const categories = [
    { name: 'Phụ kiện Action Cam', image: '/product-category-1.jpg' },
    { name: 'Tripod Điện thoại', image: '/product-category-2.jpg' },
    { name: 'Giá đỡ Điện thoại', image: '/product-category-3.jpg' },
    { name: 'Hộp chụp Sản phẩm', image: '/product-category-4.jpg' },
    { name: 'Sạc cáp Điện thoại', image: '/product-category-5.jpg' },
    { name: 'Phụ kiện insta360', image: '/product-category-6.jpg' },
    { name: 'Đèn LED Quay video', image: '/product-category-7.jpg' },
    { name: 'Mic thu âm Điện thoại', image: '/product-category-8.jpg' },
    { name: 'Hộp đựng đồ & tai nghe', image: '/product-category-9.jpg' },
    { name: 'Phụ kiện Apple', image: '/product-category-10.jpg' },
  ];
  
  return NextResponse.json({ categories });
} 