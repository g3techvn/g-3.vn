import { NextResponse } from 'next/server';

export async function GET() {
  const featuredProducts = [
    {
      id: 101,
      name: 'DJI Osmo Action 5 Pro / 4',
      category: 'Phụ kiện',
      image: '/images/featured/dji-osmo-action.jpg',
      url: '/product-category/dji-osmo'
    },
    {
      id: 102,
      name: 'Insta360 Ace Pro & Ace',
      category: 'Phụ kiện',
      image: '/images/featured/insta360-ace-pro.jpg',
      url: '/product-category/insta360-ace'
    },
    {
      id: 103,
      name: 'Insta360 X4 / X3',
      category: 'Phụ kiện',
      image: '/images/featured/insta360-x4.jpg',
      url: '/product-category/insta360-x4'
    },
    {
      id: 104,
      name: 'GoPro 13',
      category: 'Phụ kiện',
      image: '/images/featured/gopro-13.jpg',
      url: '/product-category/gopro-13'
    },
    {
      id: 105,
      name: 'Phụ kiện DJI Mic',
      category: 'Thiết bị Âm thanh',
      image: '/images/featured/dji-mic.jpg',
      url: '/product-category/dji-mic'
    },
    {
      id: 106,
      name: 'Phụ kiện GoPro Max',
      category: 'Action Cam',
      image: '/images/featured/gopro-max.jpg',
      url: '/product-category/gopro-max'
    },
    {
      id: 107,
      name: 'Insta360 GO 3',
      category: 'Action Cam',
      image: '/images/featured/insta360-go3.jpg',
      url: '/product-category/insta360-go3'
    },
    {
      id: 108,
      name: 'DJI Pocket 3',
      category: 'Máy quay cầm tay',
      image: '/images/featured/dji-pocket3.jpg',
      url: '/product-category/dji-pocket3'
    }
  ];
  
  return NextResponse.json({ featuredProducts });
} 