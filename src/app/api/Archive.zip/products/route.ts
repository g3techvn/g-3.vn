import { NextResponse } from 'next/server';

// Định nghĩa kiểu dữ liệu cho product
interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  original_price?: number;
  discount_percentage?: number;
  image_url: string;
  category_id: string;
  brand_id: string;
  brand?: string;
  rating?: number;
  created_at: string;
  updated_at: string;
}

// Mảng dữ liệu mock cho ghế công thái học GAMI
const gamiProducts = [
  {
    id: "gami-core",
    name: "Ghế Gami Core",
    description: "Ghế công thái học Gami Core, thiết kế hiện đại, hỗ trợ tư thế ngồi tối ưu.",
    price: 2050000,
    original_price: 2250000,
    discount_percentage: 9,
    image_url: "https://product.hstatic.net/200000912647/product/1_e71646180bb44ce6bd7b4515caace2ee_large.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Gami",
    brand: "Gami Việt Nam",
    rating: 4.5,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "gami-crom-all-black",
    name: "Ghế Gami Crom (Bản All Black)",
    description: "Ghế công thái học Gami Crom phiên bản All Black, thiết kế sang trọng, đẳng cấp.",
    price: 5990000,
    original_price: 6390000,
    discount_percentage: 6,
    image_url: "https://product.hstatic.net/200000912647/product/1_5b197650a67f428b87eeed2ce712480f_large.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Gami",
    brand: "Gami Việt Nam",
    rating: 5,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "gami-crom-carbon",
    name: "Ghế Gami Crom (Phiên bản lưng Carbon)",
    description: "Ghế công thái học Gami Crom phiên bản lưng Carbon, nhẹ và chắc chắn, hỗ trợ lưng tối đa.",
    price: 6890000,
    original_price: 7290000,
    discount_percentage: 5,
    image_url: "https://product.hstatic.net/200000912647/product/6_7256181dc0e040518daaaf210464741f_large.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Gami",
    brand: "Gami Việt Nam",
    rating: 4.8,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "gami-crom-pro",
    name: "Ghế Gami Crom Pro",
    description: "Ghế công thái học Gami Crom Pro, phiên bản cao cấp nhất, tích hợp nhiều tính năng hiện đại.",
    price: 12900000,
    original_price: 13500000,
    discount_percentage: 4,
    image_url: "https://product.hstatic.net/200000912647/product/crom_pro__1__d1e41a2442e84df1b2d7ae01cdcd883d_large.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Gami",
    brand: "Gami Việt Nam",
    rating: 5,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "gami-focus-v1",
    name: "Ghế Gami Focus V1",
    description: "Ghế công thái học Gami Focus V1, thiết kế tập trung vào sự thoải mái và hỗ trợ lưng.",
    price: 2690000,
    original_price: 2990000,
    discount_percentage: 10,
    image_url: "https://product.hstatic.net/200000912647/product/7_ef0717654a27469f993e2556267da3e1_large.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Gami",
    brand: "Gami Việt Nam",
    rating: 4.3,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "gami-focus-v2",
    name: "Ghế Gami Focus V2 Full lưới",
    description: "Ghế công thái học Gami Focus V2 Full lưới, thoáng mát và hỗ trợ tối đa tư thế ngồi.",
    price: 3590000,
    original_price: 3890000,
    discount_percentage: 8,
    image_url: "https://product.hstatic.net/200000912647/product/1_7c74b7ffccb54152ad0ac3272f18d5ff_large.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Gami",
    brand: "Gami Việt Nam",
    rating: 4.6,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "gami-metic",
    name: "Ghế Gami Metic",
    description: "Ghế công thái học Gami Metic, thiết kế thông minh, hỗ trợ cột sống và giảm mỏi khi ngồi lâu.",
    price: 4490000,
    original_price: 4790000,
    discount_percentage: 6,
    image_url: "https://product.hstatic.net/200000912647/product/1_7c6dda169db045579b693faf7fb8e409_large.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Gami",
    brand: "Gami Việt Nam",
    rating: 4.7,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

// Mảng dữ liệu mock cho ghế công thái học từ congthaihoc.vn
const congThaiHocProducts = [
  {
    id: "dvary-butterfly",
    name: "Ghế công thái học Dvary Butterfly",
    description: "Ghế công thái học ergonomic Dvary Butterfly chính hãng code VN tặng kèm phụ kiện. Bảo hành 5 năm, sản xuất chính hãng GT chair.",
    price: 13500000,
    original_price: 17500000,
    discount_percentage: 23,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "GTchair",
    brand: "GT Chair",
    rating: 4.8,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "ergohuman-classic",
    name: "Ghế công thái học Ergohuman Classic",
    description: "Ghế công thái học ergonomic Ergohuman bản Classic với thiết kế tinh tế, hỗ trợ tư thế ngồi tối ưu. Bảo hành 3 năm chính hãng.",
    price: 11500000,
    original_price: 12500000,
    discount_percentage: 8,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Ergohuman",
    brand: "Ergohuman",
    rating: 4.7,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "felix-6232a",
    name: "Ghế công thái học Felix 6232A",
    description: "Ghế công thái học Ergonomic Felix 6232A phù hợp với người từ 1m65. Miễn phí vận chuyển và lắp đặt nội thành Hà Nội và TP HCM.",
    price: 2900000,
    original_price: 3200000,
    discount_percentage: 9,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Felix",
    brand: "Felix",
    rating: 4.3,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "gtchair-ivino-gen2",
    name: "Ghế Công thái học GTChair Ivino Gen II",
    description: "Ghế Công thái học Ergonomic GTChair Ivino Gen II tay 5D Chính hãng, tặng kèm phụ kiện. Bảo hành chính hãng 5 năm.",
    price: 8500000,
    original_price: 12000000,
    discount_percentage: 29,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "GTchair",
    brand: "GT Chair",
    rating: 4.9,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "herman-miller-aeron",
    name: "Ghế công thái học Herman Miller Aeron",
    description: "Ghế công thái học ergonomic Herman Miller Aeron nhập khẩu, mẫu ghế làm việc mang tính biểu tượng với hơn 7 triệu sản phẩm được bán trên thế giới.",
    price: 23990000,
    original_price: 37500000,
    discount_percentage: 36,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Herman Miller",
    brand: "Herman Miller",
    rating: 5,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "sihoo-a3",
    name: "Ghế công thái học Sihoo A3 (Sihoo Doro C300)",
    description: "Ghế công thái học ergonomic Sihoo A3 với tay ghế 6D. Bảo hành chính hãng 3 năm, miễn phí giao hàng và lắp đặt tại nội thành Hà Nội & Hồ Chí Minh.",
    price: 6800000,
    original_price: 9300000,
    discount_percentage: 27,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Sihoo",
    brand: "Sihoo",
    rating: 4.8,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "sihoo-doro-s300",
    name: "Ghế công thái học Sihoo AU (Sihoo Doro S300)",
    description: "Ghế công thái học ergonomic Sihoo AU bản 3.0 2024 version mới nhất full options, tay ghế 6D. Bảo hành chính hãng 5 năm.",
    price: 11600000,
    original_price: 13000000,
    discount_percentage: 11,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Sihoo",
    brand: "Sihoo",
    rating: 4.9,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "sihoo-doro-s100",
    name: "Ghế công thái học Sihoo Doro S100",
    description: "Ghế công thái học ergonomic Sihoo Doro S100 bản chân nhôm cao cấp, tay ghế 4D. Bảo hành chính hãng 3 năm.",
    price: 6790000,
    original_price: 7090000, 
    discount_percentage: 4,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Sihoo",
    brand: "Sihoo",
    rating: 4.7,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "sihoo-m18",
    name: "Ghế công thái học Sihoo M18",
    description: "Ghế công thái học ergonomic Sihoo M18 có gác chân, bảo hành 36 tháng chính hãng Sihoo.",
    price: 2750000,
    original_price: 3250000,
    discount_percentage: 15,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Sihoo",
    brand: "Sihoo",
    rating: 4.5,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "sihoo-m57",
    name: "Ghế công thái học Sihoo M57",
    description: "Ghế công thái học ergonomic Sihoo M57 có gác chân, bảo hành 36 tháng chính hãng, thiết kế ergonomic hiện đại.",
    price: 3550000,
    original_price: 4450000,
    discount_percentage: 20,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Sihoo",
    brand: "Sihoo",
    rating: 4.6,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "sihoo-m77",
    name: "Ghế công thái học Sihoo M77",
    description: "Ghế công thái học ergonomic Sihoo M77, bảo hành chính hãng 3 năm, freeship Hà Nội và HCM.",
    price: 2390000,
    original_price: 2650000,
    discount_percentage: 10,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Sihoo",
    brand: "Sihoo",
    rating: 4.3,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "sihoo-m91c",
    name: "Ghế công thái học Sihoo M91C",
    description: "Ghế công thái học ergonomic Sihoo M91C bản tay nâng cấp 3D, bảo hành 36 tháng, phù hợp với phụ nữ và trẻ em.",
    price: 4250000,
    original_price: 4750000,
    discount_percentage: 11,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Sihoo",
    brand: "Sihoo",
    rating: 4.4,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: "sihoo-m93",
    name: "Ghế công thái học Sihoo M93",
    description: "Ghế công thái học ergonomic Sihoo M93, bảo hành chính hãng 36 tháng, cực kỳ phù hợp cho dân văn phòng.",
    price: 5390000,
    original_price: 6500000,
    discount_percentage: 17,
    image_url: "https://congthaihoc.vn/wp-content/uploads/2021/10/The%CC%82m-tie%CC%82u-de%CC%82%CC%80-phu%CC%A3-23-600x600.png",
    category_id: "ghe-cong-thai-hoc",
    brand_id: "Sihoo",
    brand: "Sihoo",
    rating: 4.7,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

// Hàm lọc và sắp xếp sản phẩm Gami
function filterAndSortGamiProducts(params: {
  minPrice?: number;
  maxPrice?: number;
  sort?: string;
  brand?: string;
}) {
  let filteredProducts = [...gamiProducts];

  // Lọc theo giá
  if (params.minPrice !== undefined) {
    filteredProducts = filteredProducts.filter(p => p.price >= params.minPrice!);
  }
  
  if (params.maxPrice !== undefined) {
    filteredProducts = filteredProducts.filter(p => p.price <= params.maxPrice!);
  }
  
  // Lọc theo thương hiệu
  if (params.brand !== undefined) {
    filteredProducts = filteredProducts.filter(p => 
      p.brand_id === params.brand || 
      p.brand === params.brand
    );
  }
  
  // Sắp xếp sản phẩm
  if (params.sort) {
    switch (params.sort) {
      case 'newest':
        filteredProducts.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        break;
      case 'price_asc':
        filteredProducts.sort((a, b) => a.price - b.price);
        break;
      case 'price_desc':
        filteredProducts.sort((a, b) => b.price - a.price);
        break;
      case 'name_asc':
        filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'name_desc':
        filteredProducts.sort((a, b) => b.name.localeCompare(a.name));
        break;
      case 'discount':
        filteredProducts.sort((a, b) => (b.discount_percentage || 0) - (a.discount_percentage || 0));
        break;
    }
  }
  
  return filteredProducts;
}

// Hàm lọc và sắp xếp sản phẩm congthaihoc
function filterAndSortCongThaiHocProducts(params: {
  minPrice?: number;
  maxPrice?: number;
  sort?: string;
  brand?: string;
}) {
  let filteredProducts = [...congThaiHocProducts];

  // Lọc theo giá
  if (params.minPrice !== undefined) {
    filteredProducts = filteredProducts.filter(p => p.price >= params.minPrice!);
  }
  
  if (params.maxPrice !== undefined) {
    filteredProducts = filteredProducts.filter(p => p.price <= params.maxPrice!);
  }
  
  // Lọc theo thương hiệu
  if (params.brand !== undefined) {
    filteredProducts = filteredProducts.filter(p => 
      p.brand_id === params.brand || 
      p.brand === params.brand
    );
  }
  
  // Sắp xếp sản phẩm
  if (params.sort) {
    switch (params.sort) {
      case 'newest':
        filteredProducts.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        break;
      case 'price_asc':
        filteredProducts.sort((a, b) => a.price - b.price);
        break;
      case 'price_desc':
        filteredProducts.sort((a, b) => b.price - a.price);
        break;
      case 'name_asc':
        filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'name_desc':
        filteredProducts.sort((a, b) => b.name.localeCompare(a.name));
        break;
      case 'discount':
        filteredProducts.sort((a, b) => (b.discount_percentage || 0) - (a.discount_percentage || 0));
        break;
    }
  }
  
  return filteredProducts;
}

export async function GET(request: Request) {
  try {
    console.log('API products được gọi (Dữ liệu ghế công thái học)');
    
    const url = new URL(request.url);
    
    // Trích xuất các tham số từ URL
    const minPrice = url.searchParams.get('minPrice') ? Number(url.searchParams.get('minPrice')) : undefined;
    const maxPrice = url.searchParams.get('maxPrice') ? Number(url.searchParams.get('maxPrice')) : undefined;
    const sort = url.searchParams.get('sort') || 'newest';
    const source = url.searchParams.get('source') || 'all'; // gami, congthaihoc, all
    const brand = url.searchParams.get('brand') || undefined;
    
    console.log('Tham số tìm kiếm:', { minPrice, maxPrice, sort, source, brand });
    
    // Kết quả cuối cùng
    let allProducts: Product[] = [];
    
    // Lấy dữ liệu từ các nguồn nội bộ
    const gamiFilteredProducts = filterAndSortGamiProducts({ minPrice, maxPrice, sort, brand });
    const congThaiHocFilteredProducts = filterAndSortCongThaiHocProducts({ minPrice, maxPrice, sort, brand });
    
    if (source === 'gami') {
      // Chỉ trả về sản phẩm Gami
      allProducts = [...gamiFilteredProducts];
    } else if (source === 'congthaihoc') {
      // Chỉ trả về sản phẩm từ congthaihoc.vn
      allProducts = [...congThaiHocFilteredProducts];
    } else {
      // Kết hợp tất cả nguồn dữ liệu nội bộ
      allProducts = [...gamiFilteredProducts, ...congThaiHocFilteredProducts];
    }
    
    // Sắp xếp lại tất cả sản phẩm theo tiêu chí đã chọn
    if (allProducts.length > 0) {
      switch (sort) {
        case 'newest':
          allProducts.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
          break;
        case 'price_asc':
          allProducts.sort((a, b) => a.price - b.price);
          break;
        case 'price_desc':
          allProducts.sort((a, b) => b.price - a.price);
          break;
        case 'name_asc':
          allProducts.sort((a, b) => a.name.localeCompare(b.name));
          break;
        case 'name_desc':
          allProducts.sort((a, b) => b.name.localeCompare(a.name));
          break;
        case 'discount':
          allProducts.sort((a, b) => (b.discount_percentage || 0) - (a.discount_percentage || 0));
          break;
      }
    }
    
    console.log(`Tổng số sản phẩm sau khi gộp: ${allProducts.length}`);
    
    return NextResponse.json({
      products: allProducts
    });
  } catch (e) {
    console.error('Unexpected error in products API:', e);
    return NextResponse.json(
      { error: 'Đã xảy ra lỗi không mong muốn', details: String(e) },
      { status: 500 }
    );
  }
} 