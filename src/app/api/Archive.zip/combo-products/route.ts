import { NextResponse } from 'next/server';

export async function GET() {
  const comboItems = [
    {
      id: 'insta360-x4-combo',
      name: 'Insta360 X4',
      description: 'Trải nghiệm quay video 360° chất lượng cao với bộ phụ kiện chính hãng Insta360 X4, camera 360 đời mới nhất của Insta360',
      image: '/images/combos/insta360-x4.svg',
      brand: 'Insta360',
      rating: 5,
      options: [
        {
          id: 1,
          name: 'Combo cơ bản: Cường lực màn hình + Hộp đựng',
          price: 650000,
          originalPrice: 750000,
          discount: 13,
          image: '/images/combos/x4-basic.svg',
          isAvailable: true
        },
        {
          id: 2,
          name: 'Combo tiêu chuẩn: Cường lực + Remote + Hộp đựng cao cấp',
          price: 1800000,
          originalPrice: 2100000,
          discount: 14,
          image: '/images/combos/x4-standard.svg',
          isAvailable: true
        },
        {
          id: 3,
          name: 'Combo đầy đủ: Gậy Selfie + Remote + Hộp đựng + Cường lực',
          price: 2450000,
          originalPrice: 2900000,
          discount: 16,
          image: '/images/combos/x4-premium.svg',
          isAvailable: false
        }
      ]
    },
    {
      id: 'insta360-ace-combo',
      name: 'Insta360 Ace Pro',
      description: 'Quay phim mượt mà với camera hành động Insta360 Ace Pro và phụ kiện chính hãng, đối thủ đáng gờm của GoPro',
      image: '/images/combos/insta360-ace-pro.svg',
      brand: 'Insta360',
      rating: 4,
      options: [
        {
          id: 4,
          name: 'Combo cơ bản: Khung kim loại + Cường lực màn hình',
          price: 700000,
          originalPrice: 800000,
          discount: 12,
          image: '/images/combos/ace-basic.svg',
          isAvailable: true
        },
        {
          id: 5,
          name: 'Combo nâng cao: Khung kim loại + Phụ kiện chống nước + Remote',
          price: 1200000,
          originalPrice: 1350000,
          discount: 11,
          image: '/images/combos/ace-advanced.svg',
          isAvailable: true
        },
        {
          id: 6,
          name: 'Combo chuyên nghiệp: Đầy đủ phụ kiện quay phim chuyên nghiệp',
          price: 1850000,
          originalPrice: 2100000,
          discount: 12,
          image: '/images/combos/ace-pro.svg',
          isAvailable: true
        }
      ]
    },
    {
      id: 'insta360-go3-combo',
      name: 'Insta360 GO 3',
      description: 'Camera mini siêu nhỏ gọn Insta360 GO 3 với khả năng gắn mọi nơi, quay phim POV đỉnh cao',
      image: '/images/combos/insta360-go3.svg',
      brand: 'Insta360',
      rating: 5,
      options: [
        {
          id: 7,
          name: 'Combo cơ bản: Base Kit + Bảo vệ ống kính',
          price: 550000,
          originalPrice: 650000,
          discount: 15,
          image: '/images/combos/go3-basic.svg',
          isAvailable: true
        },
        {
          id: 8,
          name: 'Combo nâng cao: Base Kit + Action Kit + Kẹp từ tính',
          price: 850000,
          originalPrice: 950000,
          discount: 11,
          image: '/images/combos/go3-advanced.svg',
          isAvailable: true
        },
        {
          id: 9,
          name: 'Combo đầy đủ: Tất cả phụ kiện quay video và chụp ảnh',
          price: 1350000,
          originalPrice: 1600000,
          discount: 16,
          image: '/images/combos/go3-premium.svg',
          isAvailable: true
        }
      ]
    },
    {
      id: 'insta360-x3-combo',
      name: 'Insta360 X3',
      description: 'Camera 360° Insta360 X3 đời trước với giá hấp dẫn, tương thích với nhiều phụ kiện',
      image: '/images/combos/insta360-x3.svg',
      brand: 'Insta360',
      rating: 4,
      options: [
        {
          id: 10,
          name: 'Combo tiết kiệm: Cường lực + Túi đựng cơ bản',
          price: 450000,
          originalPrice: 550000,
          discount: 18,
          image: '/images/combos/x3-basic.svg',
          isAvailable: true
        },
        {
          id: 11,
          name: 'Combo phổ thông: Gậy chống nước + Phụ kiện cơ bản',
          price: 950000,
          originalPrice: 1100000,
          discount: 13,
          image: '/images/combos/x3-standard.svg',
          isAvailable: true
        }
      ]
    },
    {
      id: 'insta360-one-rs-combo',
      name: 'Insta360 ONE RS',
      description: 'Camera thể thao Insta360 ONE RS với khả năng thay ống kính, quay 4K và 360° linh hoạt',
      image: '/images/combos/insta360-one-rs.svg',
      brand: 'Insta360',
      rating: 3,
      options: [
        {
          id: 12,
          name: 'Combo lens 4K: Lens 4K + Phụ kiện bảo vệ',
          price: 850000,
          originalPrice: 950000,
          discount: 10,
          image: '/images/combos/one-rs-4k.svg',
          isAvailable: true
        },
        {
          id: 13,
          name: 'Combo lens 360: Lens 360 + Phụ kiện thiết yếu',
          price: 1050000,
          originalPrice: 1200000,
          discount: 12,
          image: '/images/combos/one-rs-360.svg',
          isAvailable: true
        }
      ]
    },
    {
      id: 'insta360-accessories',
      name: 'Phụ kiện Insta360',
      description: 'Các phụ kiện đa năng tương thích với nhiều dòng camera Insta360, nâng cao trải nghiệm sử dụng',
      image: '/images/combos/insta360-accessories.svg',
      brand: 'Insta360',
      rating: 4,
      options: [
        {
          id: 14,
          name: 'Bộ phụ kiện đa năng: Gắn xe đạp + Đầu gắn',
          price: 450000,
          originalPrice: 550000,
          discount: 18,
          image: '/images/combos/accessories-mount.svg',
          isAvailable: true
        },
        {
          id: 15,
          name: 'Bộ phụ kiện lặn: Bộ lặn biển + Tay cầm nổi',
          price: 1250000,
          originalPrice: 1500000,
          discount: 17,
          image: '/images/combos/accessories-dive.svg',
          isAvailable: true
        }
      ]
    },
    {
      id: 'gopro-hero13-combo',
      name: 'GoPro HERO13 Black',
      description: 'Camera hành động GoPro HERO13 Black với các phụ kiện chính hãng, quay phim 5.3K siêu nét với chống rung HyperSmooth 6.0',
      image: '/images/combos/insta360-accessories.svg',
      brand: 'GoPro',
      rating: 5,
      options: [
        {
          id: 16,
          name: 'Combo cơ bản: GoPro HERO13 + Cường lực + Pin dự phòng',
          price: 1250000,
          originalPrice: 1450000,
          discount: 14,
          image: '/images/combos/accessories-mount.svg',
          isAvailable: true
        },
        {
          id: 17,
          name: 'Combo đầy đủ: GoPro HERO13 + Gậy 3-Way + Pin + Thẻ nhớ',
          price: 1950000,
          originalPrice: 2350000,
          discount: 17,
          image: '/images/combos/one-rs-4k.svg',
          isAvailable: true
        }
      ]
    },
    {
      id: 'dji-osmo-action-combo',
      name: 'DJI Osmo Action 4',
      description: 'Camera hành động DJI Osmo Action 4 với cảm biến lớn, quay 4K HDR, chống nước 18m không cần vỏ bảo vệ',
      image: '/images/combos/insta360-x3.svg',
      brand: 'DJI',
      rating: 4,
      options: [
        {
          id: 18,
          name: 'Combo Standard: DJI Osmo Action 4 + Pin dự phòng',
          price: 890000,
          originalPrice: 990000,
          discount: 10,
          image: '/images/combos/x3-basic.svg',
          isAvailable: true
        },
        {
          id: 19,
          name: 'Combo Adventure: DJI Osmo Action 4 + Gimbal + Phụ kiện',
          price: 1650000,
          originalPrice: 1900000,
          discount: 13,
          image: '/images/combos/x3-standard.svg',
          isAvailable: true
        }
      ]
    }
  ];
  
  return NextResponse.json({ comboItems });
} 