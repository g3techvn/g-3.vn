import { NextResponse } from 'next/server';

export async function GET() {
  const livestreamTabs = [
    {
      id: 'new',
      name: 'MỚI CẬP NHẬT',
      products: [
        {
          id: 205,
          sku: '978',
          name: 'KẸP ĐA NĂNG TÍCH HỢP MAGIC ARM CIMAPRO CRO-1',
          price: 300000,
          originalPrice: 400000,
          discount: 25,
          image: '/images/products/cimapro-magic-arm.jpg',
          brand: 'Cima pro',
          rating: 5,
          url: '/products/kep-da-nang-tich-hop-magic-arm-cimapro-cro-1'
        },
        {
          id: 206,
          sku: '165',
          name: 'TAY MAGIC ARM GẮN THIẾT BỊ LÊN MÁY ẢNH',
          price: 200000,
          originalPrice: 230000,
          discount: 31,
          image: '/images/products/magic-arm.jpg',
          brand: 'OEM',
          rating: 0,
          url: '/products/tay-magic-arm-gan-thiet-bi-len-may-anh'
        },
        {
          id: 211,
          sku: '395',
          name: 'KHUNG GẮN SMARTPHONE ULANZI ST-17 LIVE STREAM',
          price: 320000,
          originalPrice: 390000,
          discount: 18,
          image: '/images/products/ulanzi-smartphone-mount.jpg',
          brand: 'Ulanzi',
          rating: 3,
          url: '/products/khung-gan-smartphone-ulanzi-st-17-live-stream'
        },
        {
          id: 212,
          sku: '847',
          name: 'BỘ CHỤP SẢN PHẨM GẤP GỌN PULUZ PU5060 LED',
          price: 590000,
          originalPrice: 750000,
          discount: 21,
          image: '/images/products/puluz-studio-box.jpg',
          brand: 'Puluz',
          rating: 5,
          url: '/products/bo-chup-san-pham-gap-gon-puluz-pu5060-led'
        },
        {
          id: 201,
          sku: '928',
          name: 'GIÁ ĐỠ MÁY ẢNH QUAY TRÊN XƯƠNG KẸP CẠNH BÀN',
          price: 1100000,
          originalPrice: 1300000,
          discount: 15,
          image: '/images/products/neewer-desk-mount.jpg',
          brand: 'NEEWER',
          rating: 0,
          url: '/products/gia-do-may-anh-quay-tren-xuong-kep-canh-ban'
        },
        {
          id: 209,
          sku: '683',
          name: 'BỘ PHỤP KIỆN STREAMING ULANZI VL99 RGB MINI',
          price: 890000,
          originalPrice: 1100000,
          discount: 19,
          image: '/images/products/ulanzi-streaming-kit.jpg',
          brand: 'Ulanzi',
          rating: 4,
          url: '/products/bo-phu-kien-streaming-ulanzi-vl99-rgb-mini'
        }
      ]
    },
    {
      id: 'light',
      name: 'ĐÈN LED LIVESTREAM',
      products: [
        {
          id: 204,
          sku: '409',
          name: 'ĐÈN LIVESTREAM 46CM 50W PULUZ CHÍNH HÃNG',
          price: 700000,
          originalPrice: 920000,
          discount: 13,
          image: '/images/products/puluz-ring-light.jpg',
          brand: 'Puluz',
          rating: 0,
          url: '/products/den-livestream-46cm-50w-puluz-chinh-hang'
        },
        {
          id: 202,
          sku: '483',
          name: 'ĐÈN LED TRỢ SÁNG QUAY VIDEO CHỤP HÌNH 50W',
          price: 450000,
          originalPrice: null,
          discount: 29,
          image: '/images/products/led-video-50w.jpg',
          brand: 'OEM',
          rating: 0,
          url: '/products/den-led-tro-sang-quay-video-chup-hinh-50w'
        },
        {
          id: 203,
          sku: '866',
          name: 'ĐÈN LED KẸP CẠNH BÀN HỢP KIM NHÔM UPERGO LT-1C',
          price: 650000,
          originalPrice: 800000,
          discount: 19,
          image: '/images/products/upergo-desk-light.jpg',
          brand: 'Upergo',
          rating: 0,
          url: '/products/den-led-kep-canh-ban-hop-kim-nhom-upergo-lt-1c'
        },
        {
          id: 213,
          sku: '572',
          name: 'ĐÈN LED RGB ULANZI VIJIM R316 CHỤP SẢN PHẨM',
          price: 1250000,
          originalPrice: 1400000,
          discount: 11,
          image: '/images/products/ulanzi-rgb-light.jpg',
          brand: 'Ulanzi',
          rating: 4,
          url: '/products/den-led-rgb-ulanzi-vijim-r316-chup-san-pham'
        },
        {
          id: 214,
          sku: '619',
          name: 'ĐÈN LED MINI GODOX LEDM150 RGB CHO MÁY ẢNH',
          price: 1650000,
          originalPrice: 1800000,
          discount: 8,
          image: '/images/products/godox-ledm150.jpg',
          brand: 'Godox',
          rating: 5,
          url: '/products/den-led-mini-godox-ledm150-rgb-cho-may-anh'
        },
        {
          id: 215,
          sku: '738',
          name: 'BỘ ĐÈN LED FILL LIGHT CỔNG USB VỚI 3 CHẾ ĐỘ',
          price: 320000,
          originalPrice: 380000,
          discount: 16,
          image: '/images/products/fill-light-kit.jpg',
          brand: 'OEM',
          rating: 3,
          url: '/products/bo-den-led-fill-light-cong-usb-voi-3-che-do'
        }
      ]
    },
    {
      id: 'mic',
      name: 'MIC THU ÂM LIVESTREAM',
      products: [
        {
          id: 207,
          sku: '752',
          name: 'MIC THU ÂM LIVESTREAM BOYA BY-PM700 USB',
          price: 1950000,
          originalPrice: 2200000,
          discount: 11,
          image: '/images/products/boya-mic.jpg',
          brand: 'BOYA',
          rating: 4,
          url: '/products/mic-thu-am-livestream-boya-by-pm700-usb'
        },
        {
          id: 208,
          sku: '374',
          name: 'MIC THU ÂM LIVESTREAM MAONO AU-PM421T',
          price: 1750000,
          originalPrice: 1900000,
          discount: 8,
          image: '/images/products/maono-mic.jpg',
          brand: 'MAONO',
          rating: 5,
          url: '/products/mic-thu-am-livestream-maono-au-pm421t'
        },
        {
          id: 216,
          sku: '825',
          name: 'MIC KHÔNG DÂY SARAMONIC BLINK500 PRO B2',
          price: 3900000,
          originalPrice: 4200000,
          discount: 7,
          image: '/images/products/saramonic-mic.jpg',
          brand: 'Saramonic',
          rating: 5,
          url: '/products/mic-khong-day-saramonic-blink500-pro-b2'
        },
        {
          id: 217,
          sku: '496',
          name: 'MIC THU ÂM CÀI ÁO CHO ĐIỆN THOẠI BOYA BY-M1',
          price: 550000,
          originalPrice: 650000,
          discount: 15,
          image: '/images/products/boya-m1-mic.jpg',
          brand: 'BOYA',
          rating: 4,
          url: '/products/mic-thu-am-cai-ao-cho-dien-thoai-boya-by-m1'
        },
        {
          id: 218,
          sku: '673',
          name: 'MIC THU ÂM ĐA NĂNG PODCAST FIFINE K670B USB',
          price: 1450000,
          originalPrice: 1600000,
          discount: 9,
          image: '/images/products/fifine-mic.jpg',
          brand: 'FIFINE',
          rating: 4,
          url: '/products/mic-thu-am-da-nang-podcast-fifine-k670b-usb'
        },
        {
          id: 219,
          sku: '918',
          name: 'MIC CÀI ÁO THU ÂM ĐIỆN THOẠI PULUZ PU424',
          price: 380000,
          originalPrice: 450000,
          discount: 16,
          image: '/images/products/puluz-mic.jpg',
          brand: 'Puluz',
          rating: 3,
          url: '/products/mic-cai-ao-thu-am-dien-thoai-puluz-pu424'
        }
      ]
    },
    {
      id: 'all',
      name: 'TẤT CẢ SẢN PHẨM',
      products: [
        {
          id: 201,
          sku: '928',
          name: 'GIÁ ĐỠ MÁY ẢNH QUAY TRÊN XƯƠNG KẸP CẠNH BÀN',
          price: 1100000,
          originalPrice: 1300000,
          discount: 15,
          image: '/images/products/neewer-desk-mount.jpg',
          brand: 'NEEWER',
          rating: 0,
          url: '/products/gia-do-may-anh-quay-tren-xuong-kep-canh-ban'
        },
        {
          id: 202,
          sku: '483',
          name: 'ĐÈN LED TRỢ SÁNG QUAY VIDEO CHỤP HÌNH 50W',
          price: 450000,
          originalPrice: null,
          discount: 29,
          image: '/images/products/led-video-50w.jpg',
          brand: 'OEM',
          rating: 0,
          url: '/products/den-led-tro-sang-quay-video-chup-hinh-50w'
        },
        {
          id: 203,
          sku: '866',
          name: 'ĐÈN LED KẸP CẠNH BÀN HỢP KIM NHÔM UPERGO LT-1C',
          price: 650000,
          originalPrice: 800000,
          discount: 19,
          image: '/images/products/upergo-desk-light.jpg',
          brand: 'Upergo',
          rating: 0,
          url: '/products/den-led-kep-canh-ban-hop-kim-nhom-upergo-lt-1c'
        },
        {
          id: 204,
          sku: '409',
          name: 'ĐÈN LIVESTREAM 46CM 50W PULUZ CHÍNH HÃNG',
          price: 700000,
          originalPrice: 920000,
          discount: 13,
          image: '/images/products/puluz-ring-light.jpg',
          brand: 'Puluz',
          rating: 0,
          url: '/products/den-livestream-46cm-50w-puluz-chinh-hang'
        },
        {
          id: 205,
          sku: '978',
          name: 'KẸP ĐA NĂNG TÍCH HỢP MAGIC ARM CIMAPRO CRO-1',
          price: 300000,
          originalPrice: 400000,
          discount: 25,
          image: '/images/products/cimapro-magic-arm.jpg',
          brand: 'Cima pro',
          rating: 5,
          url: '/products/kep-da-nang-tich-hop-magic-arm-cimapro-cro-1'
        },
        {
          id: 206,
          sku: '165',
          name: 'TAY MAGIC ARM GẮN THIẾT BỊ LÊN MÁY ẢNH',
          price: 200000,
          originalPrice: 230000,
          discount: 31,
          image: '/images/products/magic-arm.jpg',
          brand: 'OEM',
          rating: 0,
          url: '/products/tay-magic-arm-gan-thiet-bi-len-may-anh'
        },
        {
          id: 211,
          sku: '395',
          name: 'KHUNG GẮN SMARTPHONE ULANZI ST-17 LIVE STREAM',
          price: 320000,
          originalPrice: 390000,
          discount: 18,
          image: '/images/products/ulanzi-smartphone-mount.jpg',
          brand: 'Ulanzi',
          rating: 3,
          url: '/products/khung-gan-smartphone-ulanzi-st-17-live-stream'
        },
        {
          id: 212,
          sku: '847',
          name: 'BỘ CHỤP SẢN PHẨM GẤP GỌN PULUZ PU5060 LED',
          price: 590000,
          originalPrice: 750000,
          discount: 21,
          image: '/images/products/puluz-studio-box.jpg',
          brand: 'Puluz',
          rating: 5,
          url: '/products/bo-chup-san-pham-gap-gon-puluz-pu5060-led'
        },
        {
          id: 209,
          sku: '683',
          name: 'BỘ PHỤP KIỆN STREAMING ULANZI VL99 RGB MINI',
          price: 890000,
          originalPrice: 1100000,
          discount: 19,
          image: '/images/products/ulanzi-streaming-kit.jpg',
          brand: 'Ulanzi',
          rating: 4,
          url: '/products/bo-phu-kien-streaming-ulanzi-vl99-rgb-mini'
        }
      ]
    }
  ];
  
  return NextResponse.json({ livestreamTabs });
} 